# Calendario de Fotos Ryutec 2026

Calendario web estático para programar colegios de julio a diciembre 2026.

## Cómo funciona

Este proyecto se puede subir completo a una carpeta de un repositorio privado de GitHub o a GitHub Pages.

Para que varios equipos vean los mismos cambios, el calendario guarda la información en `data/calendario.json` usando la API de GitHub. Cada usuario debe entrar con un token de GitHub con permiso de lectura/escritura sobre el repositorio.

## Archivos

```text
/calendario-fotos-2026/
  index.html
  assets/app.js
  assets/styles.css
  data/calendario.json
```

## Configuración rápida

1. Sube esta carpeta al repositorio privado.
2. Abre `index.html` desde GitHub Pages o desde el hosting donde publiques el repo.
3. En la pantalla inicial coloca:
   - Usuario/organización del repo
   - Nombre del repo
   - Rama, normalmente `main`
   - Ruta del JSON, por ejemplo: `calendario-fotos-2026/data/calendario.json`
   - Token de GitHub
4. Presiona **Conectar calendario**.

## Token recomendado

Crea un Fine-grained Personal Access Token en GitHub con permiso solo para este repositorio:

- Repository permissions:
  - Contents: Read and write

No coloques el token dentro del código. El sistema lo guarda solo en el navegador del usuario.

## Seguridad

- Usa un repositorio privado.
- No subas datos reales en repositorios públicos.
- No compartas el token por WhatsApp abierto.
- Si una persona deja de trabajar con el calendario, revoca su token desde GitHub.
